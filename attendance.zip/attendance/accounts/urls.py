from django.urls import path
from rest_framework.routers import DefaultRouter # type: ignore
from .views import CustomUserViewSet

router = DefaultRouter()
router.register(r'users', CustomUserViewSet)

urlpatterns = router.urls
