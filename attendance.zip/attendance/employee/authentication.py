from rest_framework.authentication import BaseAuthentication # type: ignore
from rest_framework.exceptions import PermissionDenied # type: ignore
from accounts.models import CustomUser

class SupervisorAuthentication(BaseAuthentication):
    def authenticate(self, request):
        user = request.user
        if user.is_authenticated and user.role == 'supervisor':
            return (user, None)
        raise PermissionDenied('You are not authorized to access this resource.')
