from rest_framework import viewsets, generics # type: ignore
from rest_framework.response import Response # type: ignore
from rest_framework.views import APIView # type: ignore
from rest_framework.permissions import IsAuthenticated # type: ignore
from django.http import HttpResponse
from .models import Employee, Attendance
from .serializers import EmployeeSerializer, AttendanceSerializer
from rest_framework import status # type: ignore
from .authentication import SupervisorAuthentication  # Import the custom authentication class
import qrcode # type: ignore

class EmployeeViewSet(viewsets.ModelViewSet):
    queryset = Employee.objects.all()
    serializer_class = EmployeeSerializer

class EmployeeUpdateAPIView(generics.UpdateAPIView):
    queryset = Employee.objects.all()
    serializer_class = EmployeeSerializer
    lookup_field = 'id_employee'

class EmployeeDeleteAPIView(generics.DestroyAPIView):
    queryset = Employee.objects.all()
    lookup_field = 'id_employee'

class EmployeeInfoAPIView(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request):
        employee = Employee.objects.get(user=request.user)
        serializer = EmployeeSerializer(employee)
        return Response(serializer.data)

    def post(self, request):
        employee = Employee.objects.get(user=request.user)
        employee.generate_qr_code()  # Generate QR code for the employee
        return Response({'message': 'QR code generated successfully'})

class AttendanceAPIView(APIView):
    permission_classes = [IsAuthenticated]

    def post(self, request):
        employee = Employee.objects.get(user=request.user)
        serializer = AttendanceSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save(employee=employee)
            return Response(serializer.data, status=201)
        return Response(serializer.errors, status=400)


class QRCodeScanAPIView(APIView):
    authentication_classes = [SupervisorAuthentication]  # Use the custom authentication class

    def post(self, request):
        # Assuming the scanned QR code data is sent in the request body
        scanned_data = request.data.get('scanned_data')

        # Validate the scanned data
        try:
            id_employee, name, job = scanned_data.split('\n')[:3]  # Assuming the format of scanned data is "Employee ID: {id}\nName: {name}\nJob: {job}"
        except ValueError:
            return Response({'error': 'Invalid QR code data'}, status=status.HTTP_400_BAD_REQUEST)

        # Query the employee using the scanned data
        try:
            employee = Employee.objects.get(id_employee=id_employee, name=name, job=job)
        except Employee.DoesNotExist:
            return Response({'error': 'Employee not found'}, status=status.HTTP_404_NOT_FOUND)

        # Mark attendance for the employee
        attendance = Attendance(employee=employee)
        attendance.save()

        return Response({'message': 'Attendance marked successfully'}, status=status.HTTP_201_CREATED)
