from django.db import models
from django.core.validators import MinLengthValidator, MaxLengthValidator, MinValueValidator
from django.utils.translation import gettext_lazy as _
from django.contrib.auth.models import AbstractUser
from django.contrib.auth.hashers import make_password
import qrcode # type: ignore
from io import BytesIO
from django.core.files import File
from django.utils import timezone

class Employee(models.Model):
    user                = models.OneToOneField('accounts.CustomUser', on_delete=models.CASCADE, related_name='employee_profile')
    id_employee         = models.CharField(_('Employee ID'), max_length=10, unique=True)
    name                = models.CharField(_('Name'), max_length=100)
    age                 = models.PositiveIntegerField(_('Age'), validators=[MinValueValidator(16)])
    phone_number        = models.CharField(_('Phone Number'), max_length=10, validators=[MinLengthValidator(10), MaxLengthValidator(10)])
    id_number           = models.CharField(_('ID Number'), max_length=10, unique=True)
    id_expire_date      = models.DateField(_('ID Expiry Date'))
    birthdate           = models.DateField(_('Birthdate'))
    job                 = models.CharField(_('Job'), max_length=100)
    picture             = models.ImageField(_('Picture'), upload_to='employee/pictures/', null=True, blank=True)
    id_photocopy        = models.ImageField(_('ID Photocopy'), upload_to='employee/documents/', null=True, blank=True)
    passport_photocopy  = models.ImageField(_('Passport Photocopy'), upload_to='employee/documents/', null=True, blank=True)
    cv                  = models.FileField(_('CV'), upload_to='employee/cv/', null=True, blank=True)
    account_bank_number = models.CharField(_('Bank Account Number'), max_length=100)
    bank_name           = models.CharField(_('Bank Name'), max_length=100)
    qr_code             = models.ImageField(_('QR Code'), upload_to='employee/qr_codes/', null=True, blank=True)

    def generate_qr_code(self):
        # Generate QR code content
        qr_content = f"Employee ID: {self.id_employee}\nName: {self.name}\nJob: {self.job}"

        # Create a QR code instance
        qr = qrcode.QRCode(version=1, error_correction=qrcode.constants.ERROR_CORRECT_L, box_size=10, border=4)
        qr.add_data(qr_content)
        qr.make(fit=True)

        # Create a PIL image from the QR code data
        img = qr.make_image(fill_color="black", back_color="white")

        # Save the image to a BytesIO buffer
        buffer = BytesIO()
        img.save(buffer, format='PNG')

        # Create a Django File object from the BytesIO buffer and save it to the employee model
        filename = f"{self.user.username}_qr.png"
        self.qr_code.save(filename, File(buffer), save=False)

    def __str__(self):
        return self.name

from employee.models import Employee

class Attendance(models.Model):
    employee    = models.ForeignKey(Employee, on_delete=models.CASCADE)
    date        = models.DateField(default=timezone.now)  # Date of attendance
    check_in    = models.DateTimeField(default=timezone.now)  # Check-in time
    check_out   = models.DateTimeField(null=True, blank=True)  # Check-out time
    break_out   = models.DateTimeField(null=True, blank=True)  # Break-out time
    break_in    = models.DateTimeField(null=True, blank=True)  # Break-in time

    def total_work_hours(self):
        # Calculate total work hours based on check-in, check-out, and break times
        total_hours = 0
        if self.check_out and self.check_in:
            total_hours = (self.check_out - self.check_in).total_seconds() / 3600  # Convert seconds to hours
            if self.break_out and self.break_in:
                break_hours = (self.break_out - self.break_in).total_seconds() / 3600
                total_hours -= break_hours
        return total_hours
