from django.contrib import admin
from .models import Employee
from .models import Attendance

@admin.register(Employee)
class EmployeeAdmin(admin.ModelAdmin):
    list_display = ['id_employee', 'job', 'birthdate', 'phone_number']

class AttendanceAdmin(admin.ModelAdmin):
    list_display = ['employee', 'check_in', 'check_out', 'break_in', 'break_out']

admin.site.register(Attendance, AttendanceAdmin)