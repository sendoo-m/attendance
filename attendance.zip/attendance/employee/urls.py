from django.urls import path
from rest_framework.routers import DefaultRouter
from .views import EmployeeViewSet, EmployeeUpdateAPIView, EmployeeDeleteAPIView, EmployeeInfoAPIView, AttendanceAPIView

router = DefaultRouter()
router.register(r'employees', EmployeeViewSet)

urlpatterns = router.urls + [
    path('employees/<str:id_employee>/', EmployeeUpdateAPIView.as_view(), name='employee-update'),
    path('employees/<str:id_employee>/delete/', EmployeeDeleteAPIView.as_view(), name='employee-delete'),
    path('api/employee_info/', EmployeeInfoAPIView.as_view(), name='employee-info'),
    path('api/attendance/', AttendanceAPIView.as_view(), name='attendance'),
]
